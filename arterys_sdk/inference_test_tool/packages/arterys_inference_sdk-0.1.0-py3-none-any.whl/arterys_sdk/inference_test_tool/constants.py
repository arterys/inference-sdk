DICOM_BINARY_TYPES = {'dicom_secondary_capture', 'dicom', 'dicom_structured_report', 'dicom_gsps'}

Y_SPACING = 10
X_SPACING = 5
X_INDENT = 5
